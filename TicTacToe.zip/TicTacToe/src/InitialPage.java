import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class InitialPage {

	JFrame initialFrame;
	private JTextField playerOneName;
	private JTextField playerTwoName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InitialPage window = new InitialPage();
					window.initialFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InitialPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		initialFrame = new JFrame();
		initialFrame.setBounds(100, 100, 600, 400);
		initialFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(5, 182, 147));
		initialFrame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton playBtn = new JButton("Play");
		playBtn.setFont(new Font("Rockwell", Font.BOLD, 20));
		playBtn.setBackground(new Color(255, 255, 255));
		playBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(playerOneName.getText().isEmpty() || playerTwoName.getText().isEmpty()) {
					JOptionPane.showMessageDialog(initialFrame, "Please enter player names!", "Warning", JOptionPane.INFORMATION_MESSAGE);
				} else {
					TicTacToe game = new TicTacToe();
					game.player1.setText(playerOneName.getText());
					game.player2.setText(playerTwoName.getText());
					game.frame.setVisible(true);
					initialFrame.dispose();
				}
			}
		});
		playBtn.setBounds(221, 252, 158, 37);
		panel.add(playBtn);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(5, 182, 147));
		panel_1.setBounds(0, 28, 584, 44);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("WELCOME TO");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 28));
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(new Color(5, 182, 147));
		panel_1_1.setBounds(0, 66, 584, 44);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("TicTacToe");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Rockwell", Font.BOLD, 28));
		panel_1_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel = new JLabel("Player 1 Name:");
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(137, 134, 158, 43);
		panel.add(lblNewLabel);
		
		playerOneName = new JTextField();
		playerOneName.setBounds(271, 144, 174, 26);
		playerOneName.setText("");
		panel.add(playerOneName);
		playerOneName.setColumns(10);
		
		JLabel lblPlayerName = new JLabel("Player 2 Name:");
		lblPlayerName.setForeground(Color.WHITE);
		lblPlayerName.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblPlayerName.setBounds(137, 178, 158, 43);
		panel.add(lblPlayerName);
		
		playerTwoName = new JTextField();
		playerTwoName.setColumns(10);
		playerTwoName.setBounds(271, 188, 174, 26);
		playerTwoName.setText("");
		panel.add(playerTwoName);
	}
}
