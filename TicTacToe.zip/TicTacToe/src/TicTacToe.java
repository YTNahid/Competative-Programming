import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import javax.swing.JComboBox;
//import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;

public class TicTacToe {

	JFrame frame;
	private JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
	JTextField player1;
	JTextField player2;
	private JTextField score1;
	private JTextField score2;
	private JLabel turnLabel;
	private String startGame = "X";
	private int cnt, xCnt, oCnt;
	private boolean checker;	
	private int turn;
	private int b1 = 2, b2 = 2, b3 = 2, b4 = 2, b5 = 2, b6 = 2, b7 = 2, b8 = 2, b9 = 2;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicTacToe window = new TicTacToe();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TicTacToe() {
		initialize();
	}
	
	// Updates Score in the Score box
	private void updateScore() { 
		score1.setText(String.valueOf(xCnt));
		score2.setText(String.valueOf(oCnt));
	}
	
	// Checks if the game has ended
	private boolean checkerWarning() { 
		if(checker) {
			JOptionPane.showMessageDialog(frame, "Please reset the game first", "Warning", JOptionPane.INFORMATION_MESSAGE);
			return true;
		}
		
		return false;
	}
	
	// Sets 'X' or 'O' for each player turn
	private void player() { 
		if(startGame.equals("X")) {
			startGame = "O";
		} else {
			startGame = "X";
		}
	}
	
	// Changes turns for player in each game
	private void changeTurn() { 
		if(turn%2 == 0) startGame = "X";
		else startGame = "O";
		
	}
	
	// Check if 'X' or 'O' is playing, shows it below player name
	private String checkTurn() { 
		if(checker) {
			return "Game Over...";
		} else if(startGame.equals("X")) {
			return "[ X ]'s turn...";
		} else {
			return "[ O ]'s turn...";
		}
	}
	
	// Shows warning if a button is already pressed
	private void checkTwice(JButton c) { 
		if(c.getText() != "") JOptionPane.showMessageDialog(frame, "Invalid Selection!", "TicTacToe", JOptionPane.INFORMATION_MESSAGE);
	}
	
	// Checking if button is already pressed
	private boolean checkText(JButton c) { 
		if(c.getText() != "") return false;
		return true;
	}
	
	// Show dialogue if player 1 wins
	private void winDiagP1() { 
		String p1Name = player1.getText();
		JOptionPane.showMessageDialog(frame, p1Name + " Wins!", "Game Over!", JOptionPane.INFORMATION_MESSAGE);
	}
	
	// Show dialogue if player 2 wins
	private void winDiagP2() { 
		String p2Name = player2.getText();
		JOptionPane.showMessageDialog(frame, p2Name + " Wins!", "Game Over!", JOptionPane.INFORMATION_MESSAGE);
	}
	
	// Change BG color after winning
	private void changeBG(JButton b1, JButton b2, JButton b3) { 
		b1.setBackground(new Color(166, 243, 228));
		b2.setBackground(new Color(166, 243, 228));
		b3.setBackground(new Color(166, 243, 228));
	}
	
	// What happens when a player wins
	private void winAction(JButton bt1, JButton bt2, JButton bt3, int winner) {
		changeBG(bt1, bt2, bt3);
		if(winner == 1) {
			winDiagP1();
			xCnt++;
		}
		else if(winner == 0) {
			winDiagP2();
			oCnt++;
		}
		updateScore();
		checker = true;
	}
	
	// Check if anyone won
	private void winGame() { 
		//Check Player 1 
		if(b1 == 1 && b2 == 1 && b3 == 1) winAction(btn1, btn2, btn3, 1);
		else if(b4 == 1 && b5 == 1 && b6 == 1) winAction(btn4, btn5, btn6, 1);
		else if(b7 == 1 && b8 == 1 && b9 == 1) winAction(btn7, btn8, btn9, 1);
		else if(b1 == 1 && b4 == 1 && b7 == 1) winAction(btn1, btn4, btn7, 1);
		else if(b2 == 1 && b5 == 1 && b8 == 1) winAction(btn2, btn5, btn8, 1);
		else if(b3 == 1 && b6 == 1 && b9 == 1) winAction(btn3, btn6, btn9, 1);
		else if(b1 == 1 && b5 == 1 && b9 == 1) winAction(btn1, btn5, btn9, 1);
		else if(b3 == 1 && b5 == 1 && b7 == 1) winAction(btn3, btn5, btn7, 1);	
		
		//Check Player 2
		else if(b1 == 0 && b2 == 0 && b3 == 0) winAction(btn1, btn2, btn3, 0);
		else if(b4 == 0 && b5 == 0 && b6 == 0) winAction(btn4, btn5, btn6, 0);
		else if(b7 == 0 && b8 == 0 && b9 == 0) winAction(btn7, btn8, btn9, 0);
		else if(b1 == 0 && b4 == 0 && b7 == 0) winAction(btn1, btn4, btn7, 0);
		else if(b2 == 0 && b5 == 0 && b8 == 0) winAction(btn2, btn5, btn8, 0);
		else if(b3 == 0 && b6 == 0 && b9 == 0) winAction(btn3, btn6, btn9, 0);
		else if(b1 == 0 && b5 == 0 && b9 == 0) winAction(btn1, btn5, btn9, 0);
		else if(b3 == 0 && b5 == 0 && b7 == 0) winAction(btn3, btn5, btn7, 0);
		
		//Draw
		else if(cnt == 9) {
			JOptionPane.showMessageDialog(frame, "Draw!", "Game Over!", JOptionPane.INFORMATION_MESSAGE);
			checker = true;
		}
	}
	
	// What happens when a button is clicked
	private void btnAction(JButton btn, int b) {
		checkerWarning();
		if(!checker) checkTwice(btn);
		if(!checker && checkText(btn)) {
			btn.setText(startGame);
			if(startGame.equals("X")) {
				btn.setForeground(new Color(5, 182, 147));
				cnt++;
				if(b == 1) b1 = 1;
				else if(b == 2) b2 = 1;
				else if(b == 3) b3 = 1;
				else if(b == 4) b4 = 1;
				else if(b == 5) b5 = 1;
				else if(b == 6) b6 = 1;
				else if(b == 7) b7 = 1;
				else if(b == 8) b8 = 1;
				else if(b == 9) b9 = 1;
			} else {
				btn.setForeground(new Color(28, 47, 67));
				cnt++;
				if(b == 1) b1 = 0;
				else if(b == 2) b2 = 0;
				else if(b == 3) b3 = 0;
				else if(b == 4) b4 = 0;
				else if(b == 5) b5 = 0;
				else if(b == 6) b6 = 0;
				else if(b == 7) b7 = 0;
				else if(b == 8) b8 = 0;
				else if(b == 9) b9 = 0;
			}
			
			player();					
			winGame();
			turnLabel.setText(checkTurn());
		}
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {	
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		changeTurn();
		turn++;
		
		JPanel panel = new JPanel();
		panel.setBorder(null);
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		turnLabel = new JLabel(checkTurn());
		turnLabel.setFont(new Font("Rockwell", Font.BOLD, 14));
		turnLabel.setForeground(new Color(5, 182, 147));
		turnLabel.setBounds(364, 159, 210, 23);
		panel.add(turnLabel);
		
		btn1 = new JButton("");
		btn1.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn1.setForeground(new Color(5, 182, 147));
		btn1.setBorder(null);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn1, 1);
			}
		});
		btn1.setBackground(new Color(255, 255, 255));
		btn1.setBounds(10, 46, 108, 94);
		panel.add(btn1);
		
		btn2 = new JButton("");
		btn2.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn2.setBorder(null);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn2, 2);
			}
		});
		btn2.setForeground(new Color(5, 182, 147));
		btn2.setBackground(new Color(255, 255, 255));
		btn2.setBounds(128, 46, 108, 94);
		panel.add(btn2);
		
		btn3 = new JButton("");
		btn3.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn3.setBorder(null);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn3, 3);
			}
		});
		btn3.setForeground(new Color(5, 182, 147));
		btn3.setBackground(new Color(255, 255, 255));
		btn3.setBounds(246, 46, 108, 94);
		panel.add(btn3);
		
		btn4 = new JButton("");
		btn4.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn4.setBorder(null);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn4, 4);
			}
		});
		btn4.setForeground(new Color(5, 182, 147));
		btn4.setBackground(new Color(255, 255, 255));
		btn4.setBounds(10, 151, 108, 94);
		panel.add(btn4);
		
		btn5 = new JButton("");
		btn5.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn5.setBorder(null);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn5, 5);
			}
		});
		btn5.setForeground(new Color(5, 182, 147));
		btn5.setBackground(new Color(255, 255, 255));
		btn5.setBounds(128, 151, 108, 94);
		panel.add(btn5);
		
		btn6 = new JButton("");
		btn6.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn6.setBorder(null);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn6, 6);
			}
		});
		btn6.setForeground(new Color(5, 182, 147));
		btn6.setBackground(new Color(255, 255, 255));
		btn6.setBounds(246, 151, 108, 94);
		panel.add(btn6);
		
		btn7 = new JButton("");
		btn7.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn7.setBorder(null);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn7, 7);
			}
		});
		btn7.setForeground(new Color(5, 182, 147));
		btn7.setBackground(new Color(255, 255, 255));
		btn7.setBounds(10, 256, 108, 94);
		panel.add(btn7);
		
		btn8 = new JButton("");
		btn8.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn8.setBorder(null);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn8, 8);
			}
		});
		btn8.setForeground(new Color(5, 182, 147));
		btn8.setBackground(new Color(255, 255, 255));
		btn8.setBounds(128, 256, 108, 94);
		panel.add(btn8);
		
		btn9 = new JButton("");
		btn9.setFont(new Font("Rockwell", Font.BOLD, 55));
		btn9.setBorder(null);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAction(btn9, 9);
			}
		});
		btn9.setForeground(new Color(5, 182, 147));
		btn9.setBackground(new Color(255, 255, 255));
		btn9.setBounds(246, 256, 108, 94);
		panel.add(btn9);
		
		JButton resetScore = new JButton("Reset Score");
		resetScore.setFont(new Font("Rockwell", Font.BOLD, 14));
		resetScore.setBorder(null);
		resetScore.setForeground(new Color(255, 255, 255));
		resetScore.setBackground(new Color(59, 198, 171));
		resetScore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				score1.setText("0");
				score2.setText("0");
				xCnt = 0;
				oCnt = 0;
			}
		});
		resetScore.setBounds(364, 241, 129, 29);
		panel.add(resetScore);
		
		JButton resetBoard = new JButton("Reset Board");
		resetBoard.setFont(new Font("Rockwell", Font.BOLD, 14));
		resetBoard.setBorder(null);
		resetBoard.setForeground(new Color(255, 255, 255));
		resetBoard.setBackground(new Color(59, 198, 171));
		resetBoard.setBounds(364, 281, 129, 29);
		resetBoard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setText("");
				btn2.setText("");
				btn3.setText("");
				btn4.setText("");
				btn5.setText("");
				btn6.setText("");
				btn7.setText("");
				btn8.setText("");
				btn9.setText("");
				btn1.setBackground(new Color(255, 255, 255));
				btn2.setBackground(new Color(255, 255, 255));
				btn3.setBackground(new Color(255, 255, 255));
				btn4.setBackground(new Color(255, 255, 255));
				btn5.setBackground(new Color(255, 255, 255));
				btn6.setBackground(new Color(255, 255, 255));
				btn7.setBackground(new Color(255, 255, 255));
				btn8.setBackground(new Color(255, 255, 255));
				btn9.setBackground(new Color(255, 255, 255));
				b1 = 2;
				b2 = 2;
				b3 = 2;
				b4 = 2;
				b5 = 2;
				b6 = 2;
				b7 = 2;
				b8 = 2;
				b9 = 2;
				cnt = 0;
				checker = false;
				changeTurn();
				turn++;
				turnLabel.setText(checkTurn());
			}
		});
		panel.add(resetBoard);
		
		JButton exit = new JButton("Exit");
		exit.setFont(new Font("Rockwell", Font.BOLD, 14));
		exit.setBorder(null);
		exit.setForeground(new Color(255, 255, 255));
		exit.setBackground(new Color(59, 198, 171));
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame = new JFrame("Exit");
				if(JOptionPane.showConfirmDialog(frame, "Are you sure you want to exit?", "Exit TicTacToe", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		exit.setBounds(364, 321, 129, 29);
		panel.add(exit);
		
		player1 = new JTextField();
		player1.setEditable(false);
		player1.setFont(new Font("Rockwell", Font.PLAIN, 11));
		player1.setBounds(364, 89, 86, 20);
		panel.add(player1);
		player1.setColumns(10);
		
		player2 = new JTextField();
		player2.setEditable(false);
		player2.setFont(new Font("Rockwell", Font.PLAIN, 11));
		player2.setBounds(364, 120, 86, 20);
		panel.add(player2);
		player2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("TicTacToe");
		lblNewLabel.setBackground(new Color(5, 182, 147));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Rockwell", Font.BOLD, 28));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 0, 564, 42);
		panel.add(lblNewLabel);
		
		score1 = new JTextField();
		score1.setEditable(false);
		score1.setFont(new Font("Rockwell", Font.PLAIN, 11));
		score1.setText("0");
		score1.setHorizontalAlignment(SwingConstants.CENTER);
		score1.setBounds(460, 89, 33, 20);
		panel.add(score1);
		score1.setColumns(10);
		
		score2 = new JTextField();
		score2.setEditable(false);
		score2.setFont(new Font("Rockwell", Font.PLAIN, 11));
		score2.setHorizontalAlignment(SwingConstants.CENTER);
		score2.setText("0");
		score2.setBounds(460, 120, 33, 20);
		panel.add(score2);
		score2.setColumns(10);
		
		JButton newGame = new JButton("New Game");
		newGame.setFont(new Font("Rockwell", Font.BOLD, 20));
		newGame.setBorder(null);
		newGame.setForeground(new Color(255, 255, 255));
		newGame.setBackground(new Color(59, 198, 171));
		newGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btn1.setText("");
				btn2.setText("");
				btn3.setText("");
				btn4.setText("");
				btn5.setText("");
				btn6.setText("");
				btn7.setText("");
				btn8.setText("");
				btn9.setText("");
				btn1.setBackground(new Color(255, 255, 255));
				btn2.setBackground(new Color(255, 255, 255));
				btn3.setBackground(new Color(255, 255, 255));
				btn4.setBackground(new Color(255, 255, 255));
				btn5.setBackground(new Color(255, 255, 255));
				btn6.setBackground(new Color(255, 255, 255));
				btn7.setBackground(new Color(255, 255, 255));
				btn8.setBackground(new Color(255, 255, 255));
				btn9.setBackground(new Color(255, 255, 255));
				player1.setText("Player 1");
				player2.setText("Player 2");
				score1.setText("0");
				score2.setText("0");
				b1 = 2;
				b2 = 2;
				b3 = 2;
				b3 = 2;
				b4 = 2;
				b5 = 2;
				b6 = 2;
				b7 = 2;
				b8 = 2;
				b9 = 2;
				cnt = 0;
				checker = false;
				startGame = "X";
				turnLabel.setText(checkTurn());
				xCnt = 0;
				oCnt = 0;
				turn = 0;
				changeTurn();
				turn++;
				
				InitialPage ip = new InitialPage();
				ip.initialFrame.setVisible(true);
				frame.dispose();
			}
		});
		newGame.setBounds(364, 46, 210, 32);
		panel.add(newGame);
		
		JLabel lblNewLabel_1 = new JLabel("Menu");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblNewLabel_1.setBounds(379, 205, 195, 25);
		panel.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(166, 243, 228));
		panel_1.setBounds(10, 46, 344, 304);
		panel.add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(59, 198, 171));
		panel_2.setBounds(10, 0, 564, 42);
		panel.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(59, 198, 171));
		panel_3.setBounds(364, 201, 210, 32);
		panel.add(panel_3);
		
		JLabel lblNewLabel_3 = new JLabel("X");
		lblNewLabel_3.setBounds(515, 91, 9, 15);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setFont(new Font("Rockwell", Font.BOLD, 12));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
	}
}
